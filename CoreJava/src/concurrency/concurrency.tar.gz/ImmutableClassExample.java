package concurrency;

public class ImmutableClassExample {

	
	
	
}
